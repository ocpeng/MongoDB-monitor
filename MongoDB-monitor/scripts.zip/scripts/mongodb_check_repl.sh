#!/bin/bash

begin=`echo $[$(date +%s%N)/1000000]`
res=`/usr/local/mongodb/bin/mongo --port $1 -u 'zabbix' -p 'Mac!19hA8QdXM7fj' --authenticationDatabase "monitor" monitor --quiet --eval 'rs.slaveOk();c=db.monitor.find();c.forEach(function(doc){print(doc._id)})'`
end=`echo $[$(date +%s%N)/1000000]`
response_time=$[$end-$begin]


if [ $res = 1 ]; then
	connect=1;
else 
	connect=0;
fi

ipaddr=`/sbin/ifconfig -a|grep inet|grep -v 127.0.0.1|grep -v inet6|awk '{print $2}'|tr -d "addr:"`
replicaset_state=`echo "rs.status()" | /usr/local/mongodb/bin/mongo  --port $1 -u 'zabbix' -p 'Mac!19hA8QdXM7fj' --authenticationDatabase "admin" |grep -E 'name|stateStr'|grep -A1 ${ipaddr}|sed 's/["|,|[:space:]]//g'|grep stateStr`

if [ "${replicaset_state}" = "stateStr:PRIMARY" ]; then
	repl_status=1;
elif [ "${replicaset_state}" = "stateStr:SECONDARY" ]; then
	repl_status=0;
fi

repl_delay=`/bin/echo "rs.printSlaveReplicationInfo()" | /usr/local/mongodb/bin/mongo  -u 'zabbix' -p 'Mac!19hA8QdXM7fj' --authenticationDatabase "admin"  --port $1 --quiet|grep -A2 ${ipaddr} |tail -1| awk '{print $1}'|sed 's/[- ]//g'`

if [ $2 = "response_time" ]; then
	echo $response_time;
elif [ $2 = "connect" ]; then
	echo $connect;
elif [ $2 = "repl_status" ]; then
	echo $repl_status
elif [ $2 = "repl_delay" ]; then
	#echo $repl_delay
	if [ ! $repl_delay ]; then
		repl_delay=0;
		echo ${repl_delay};
	else 
		echo ${repl_delay};
	fi
fi

