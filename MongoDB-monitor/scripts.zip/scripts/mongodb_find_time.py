# -*- coding: utf-8 -*-

from pymongo import MongoClient
import time
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

T = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
ip='localhost'
port = int(sys.argv[1])

def Mongo_monitor(ip,port):
    error = 0
    Out = 0
    try:
        conn = MongoClient(ip,port)
        db_auth = conn.monitor
        db_auth.authenticate("monitor", "sppfejfejkfjeTEew")
    except Exception, E:
        print E
        error = u'数据库链接失败'
    try:
        Out = db_auth.monitor.find_one()['_id']
        #print Out
        if Out != 1:
           error = u'数据库查询结果不正确'
    except:
           error = u'数据库查询失败'
    conn.close()
    return error


Begin = time.time()
Mongo_monitor(ip,port)
End = time.time()
RunTime = End - Begin
print "%.3f" % (RunTime)
