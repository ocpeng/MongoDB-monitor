#!/usr/bin/env python
# -*- coding: utf-8 -*-

import mysql.connector
import time
import sys

ip = '127.0.0.1'
port = sys.argv[1]

def Mysql_monitor(ip,port):
    config = {
              'user':'zabbix',
              'password':'Mac!19hA8QdXM7fj',
              'host':ip,
              'port':port,
              'database':'monitor'}
    try:
        conn = mysql.connector.connect(**config)
        # 创建游标
        cur = conn.cursor()
    except:
        print '数据库链接失败'
    else:
        # 执行查询SQL
        sql = "select id from monitor;"
        try:
            cur.execute(sql)
        except:
            print '数据库查询失败'
        # 获取查询结果
        result_set = cur.fetchall()
        # 关闭游标和连接
        cur.close()
        conn.close()

Begin = time.time()
Mysql_monitor(ip,port)
End = time.time()
RunTime = End - Begin
print "%.3f" % (RunTime)
